const Sequelize = require("sequelize");
const sequelize = new Sequelize("practical_exam", "root", "agc123", {
  host: "localhost",
  dialect: "mysql",
  define: {
    timestamps: false,
  },
});

module.exports = sequelize;
