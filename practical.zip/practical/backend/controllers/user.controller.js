const User = require("../models/user.model");
const login = async (req, res) => {
  try {
    const users = await User.findOne({
      attributes: ["id", "name", "email"],
      where: { email: req.body.email, password: req.body.password },
    });
    if (!users) {
      return res.status(401).send("Invalid email or password.");
    }
    return res.status(200).json({ users });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

const register = async (req, res) => {
  try {
    const isUsers = await User.findOne({
      attributes: ["id", "name", "email"],
      where: { email: req.body.email },
    });
    if (isUsers) {
      return res.status(401).send("User Already Registered");
    }
    console.log("req.body", req.body.name);
    const users = await User.create({
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
    });
    return res.status(200).json({ users });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

module.exports = {
  login,
  register,
};
