const Product = require("../models/product.model");
const getProduct = async (req, res) => {
  try {
    const products = await Product.findOne({
      attributes: [
        "id",
        "name",
        "image",
        "product_code",
        "price",
        "category",
        "manufacture_date",
        "expiry_date",
        "owner",
        "status",
      ],
    });
    return res.status(200).json({ products });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

const createProduct = async (req, res) => {
  try {
    const products = await Product.create(req.body);
    return res.status(200).json({ products });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

const updateProduct = async (req, res) => {
  try {
    const products = await Product.update(req.body, {
      where: { id: req.params.id },
    });
    return res.status(200).json({ products });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

const deleteProduct = async (req, res) => {
  try {
    const products = await Product.destroy({
      where: { id: req.params.id },
    });
    return res.status(200).json({ products });
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

module.exports = {
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
};
