const express = require("express");
const dotenv = require("dotenv");
var bodyParser = require("body-parser");
const sequelize = require("./connection");
const { login, register } = require("./controllers/user.controller");
var cors = require("cors");
const {
  getProduct,
  createProduct,
  updateProduct,
  deleteProduct,
} = require("./controllers/product.controller");
const app = express();
dotenv.config();
app.use(bodyParser.json());
app.use(cors(["*"]));
sequelize
  .authenticate()
  .then(() => {
    app.post("/login", login);
    app.post("/register", register);
    app.get("/product", getProduct);
    app.post("/addproduct", createProduct);
    app.post("/updateproduct/:id", updateProduct);
    app.delete("/deleteproduct/:id", deleteProduct);

    app.listen(process.env.PORT, () => {
      console.log(`Server running at http://localhost:${process.env.PORT}`);
    });
    console.log("Connection has been established successfully.");
  })
  .catch((error) => {
    console.error("Unable to connect to the database: ", error);
  });
