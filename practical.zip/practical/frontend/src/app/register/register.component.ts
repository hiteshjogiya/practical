import { Component, OnInit } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { LoginService } from '../login.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    MatSlideToggleModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    ReactiveFormsModule,
    CommonModule,
  ],
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss',
})
export class RegisterComponent implements OnInit {
  registerForm: any;
  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private matSnackbar: MatSnackBar,
    private router: Router
  ) {}

  ngOnInit() {
    this.registerForm = this.fb.group({
      email: ['', Validators.required],
      password: ['', Validators.required],
      name: ['', Validators.required],
    });
  }
  onSubmit() {
    console.log('(this.registerForm.value', this.registerForm.value);
    this.loginService.register(this.registerForm.value).subscribe(
      (res) => {
        this.matSnackbar.open('User Login Successfully', 'Close', {
          duration: 2000,
        });
        this.router.navigate(['/login']);
      },
      (error) => {
        // Handle login error
        this.matSnackbar.open('User Already Exists', 'Close', {
          duration: 2000,
        });
        console.error(error);
      }
    );
  }
}
