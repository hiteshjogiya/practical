import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';

import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogRef,
  MatDialogTitle,
} from '@angular/material/dialog';
import { AddProductsComponent } from '../add-products/add-products.component';
const ELEMENT_DATA: any[] = [
  {
    name: 'Hydrogen',
    image: 'abc',
    product_code: 'H',
    price: 123,
    category: 'abc',
    manufacture_date: '2015',
    expiry_date: '123',
    owner: 'ad',
    status: '123',
  },
];

@Component({
  selector: 'app-product',
  standalone: true,
  imports: [
    MatTableModule,
    MatButtonModule,
    MatDialogActions,
    MatDialogClose,
    MatDialogContent,
    MatDialogTitle,
  ],
  templateUrl: './product.component.html',
  styleUrl: './product.component.scss',
})
export class ProductComponent {
  constructor(private dialog: MatDialog) {}
  displayedColumns: string[] = [
    'name',
    'image',
    'product_code',
    'price',
    'category',
    'manufacture_date',
    'expiry_date',
    'owner',
    'status',
    'action',
  ];
  dataSource = ELEMENT_DATA;

  addProduct() {
    const dialogRef = this.dialog.open(AddProductsComponent, {
      width: '50%',
    });
    dialogRef.afterClosed().subscribe((result) => {
      console.log('The dialog was closed');
      if (result !== undefined) {
      }
    });
  }
}
