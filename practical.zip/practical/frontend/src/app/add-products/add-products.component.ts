import { Component, OnInit, inject } from '@angular/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { LoginService } from '../login.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';
@Component({
  selector: 'app-add-products',
  standalone: true,
  imports: [
    MatSlideToggleModule,
    MatSelectModule,
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    ReactiveFormsModule,
    CommonModule,
    MatDatepickerModule,
  ],
  providers: [provideNativeDateAdapter()],
  templateUrl: './add-products.component.html',
  styleUrl: './add-products.component.scss',
})
export class AddProductsComponent implements OnInit {
  readonly dialogRef = inject(MatDialogRef<AddProductsComponent>);
  productForm: any;
  readonly data = inject<any>(MAT_DIALOG_DATA);

  ngOnInit() {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      image: ['', Validators.required],
      product_code: ['', Validators.required],
      price: ['', Validators.required],
      category: ['', Validators.required],
      manufacture_date: ['', Validators.required],
      expiry_date: ['', Validators.required],
      owner: ['', Validators.required],
      status: ['', Validators.required],
    });
  }
  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private matSnackbar: MatSnackBar,
    private router: Router
  ) {}

  onSubmit() {
    console.log('this.productForm.value', this.productForm.value);
    // this.loginService.register(this.productForm.value).subscribe(
    //   (res) => {
    //     this.matSnackbar.open('User Login Successfully', 'Close', {
    //       duration: 2000,
    //     });
    //     this.router.navigate(['/login']);
    //   },
    //   (error) => {
    //     // Handle login error
    //     this.matSnackbar.open('User Already Exists', 'Close', {
    //       duration: 2000,
    //     });
    //     console.error(error);
    //   }
    // );
  }
}
