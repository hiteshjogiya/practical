import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-K5KTPMZK.js";
import "./chunk-AVEEFEPW.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-VQWLEULB.js";
import "./chunk-6XTSTQLC.js";
import "./chunk-F7V2OFJF.js";
import "./chunk-ITEN6JWW.js";
import "./chunk-T6UFPF3R.js";
import "./chunk-EPAV4CNQ.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
